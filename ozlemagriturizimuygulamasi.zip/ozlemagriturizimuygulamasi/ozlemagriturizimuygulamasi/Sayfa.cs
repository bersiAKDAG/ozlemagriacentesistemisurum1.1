﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ozlemagriturizimuygulamasi
{
    public static class Sayfa
    {
        static bool geciyor;

        // Menüdeki 4 görünmez alanı formun üstüne kurar
        public static void MenuKur(Form f, Rectangle genel, Rectangle bilet, Rectangle satis, Rectangle cikis)
        {
            Alan(f, genel, (s, e) => { if (!(f is acentepaneli)) Git(f, new acentepaneli()); });
            Alan(f, bilet, (s, e) => { if (!(f is biletsat)) Git(f, new biletsat()); });
            Alan(f, satis, (s, e) => { if (!(f is sonsatislar)) Git(f, new sonsatislar()); });
            Alan(f, cikis, (s, e) => Cikis(f));
            f.FormClosed += (s, e) => { if (!geciyor) Application.Exit(); };   // X ile kapatınca program biter
        }

        static void Alan(Form f, Rectangle r, EventHandler tikla)
        {
            var l = new Label();
            l.AutoSize = false;
            l.BackColor = Color.Transparent;
            l.Bounds = r;
            l.Cursor = Cursors.Hand;
            l.Click += tikla;
            f.Controls.Add(l);
            l.BringToFront();
        }

        static void Git(Form mevcut, Form yeni)
        {
            geciyor = true;
            yeni.StartPosition = FormStartPosition.Manual;
            yeni.Location = mevcut.Location;   // aynı yerde açılsın
            yeni.Show();                       // önce yenisi açılır, titreme olmaz
            mevcut.Close();                    // sonra eskisi kapanır
            geciyor = false;
        }

        static void Cikis(Form mevcut)
        {
            geciyor = true;
            foreach (Form f in Application.OpenForms)
                if (f is sistemegiris) { ((sistemegiris)f).GirisEkraninaDon(); break; }
            mevcut.Close();
            geciyor = false;
        }
    }
}