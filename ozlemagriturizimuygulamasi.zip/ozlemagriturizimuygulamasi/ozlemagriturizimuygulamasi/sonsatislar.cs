﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace ozlemagriturizimuygulamasi
{
    public partial class sonsatislar : Form
    {
        // Tasarımdaki renkler
        static readonly Color Zemin = Color.FromArgb(245, 247, 250);
        static readonly Color Lacivert = Color.FromArgb(10, 21, 36);
        static readonly Color Gri = Color.FromArgb(100, 116, 139);
        static readonly Color Cizgi = Color.FromArgb(226, 232, 240);

        DataGridView grid;
        Label lblBos;
        bool yuklendi;

        public sonsatislar()
        {
            InitializeComponent();

            Text = "Özlem Ağrı Turizm - Satışlarım";
            ClientSize = new Size(1113, 641);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Sayfa.MenuKur(this,
                new Rectangle(10, 146, 166, 36),   // Genel Bakış
                new Rectangle(10, 185, 166, 36),   // Bilet Sat
                new Rectangle(10, 225, 166, 41),   // Satışlarım
                new Rectangle(10, 587, 166, 33));  // Çıkış Yap

            ArayuzKur();

            // Designer'daki Load bağlantısı bir sebeple yoksa yine de yüklensin
            Shown += (s, e) => { if (!yuklendi) SatislariYukle(); };
        }

        // Designer'daki Load olayına bağlı mevcut metot
        private void sonsatislar_Load(object sender, EventArgs e)
        {
            SatislariYukle();
        }

        // ---------------------------------------------------------------
        //  Arayüz (sol menü resimde kalıyor, sağ taraf gerçek kontroller)
        // ---------------------------------------------------------------
        void ArayuzKur()
        {
            var icerik = new Panel();
            icerik.BackColor = Zemin;
            icerik.Location = new Point(188, 0);
            icerik.Size = new Size(ClientSize.Width - 188, ClientSize.Height);
            Controls.Add(icerik);

            icerik.Controls.Add(Etiket("Satışlarım", 26, 24, new Font("Segoe UI", 18F, FontStyle.Bold), Lacivert));
            icerik.Controls.Add(Etiket("Sizin üzerinizden satılan tüm biletler", 28, 64, new Font("Segoe UI", 9.5F), Gri));

            Panel kart = Kart(26, 100, icerik.Width - 52, ClientSize.Height - 100 - 24);
            kart.Padding = new Padding(1);
            icerik.Controls.Add(kart);

            grid = new DataGridView();
            GridStili(grid);
            grid.Dock = DockStyle.Fill;
            kart.Controls.Add(grid);

            grid.Columns.Add(Kolon("colKod", "KOD", "Kod", 11, null));
            grid.Columns.Add(Kolon("colYolcu", "YOLCU", "Ad", 16, null));
            grid.Columns.Add(Kolon("colGuzergah", "GÜZERGAH", "Guzergah", 20, null));
            grid.Columns.Add(Kolon("colTarih", "TARİH", "TarihSaat", 15, null));
            grid.Columns.Add(Kolon("colKoltuk", "KOLTUK", "Koltuklar", 8, null));
            grid.Columns.Add(Kolon("colTutar", "TUTAR (TL)", "Tutar", 10, "N2"));
            grid.Columns.Add(Kolon("colKomisyon", "KOMİSYON (TL)", "KomisyonTutari", 10, "N2"));
            grid.Columns.Add(Kolon("colDurum", "DURUM", "Durum", 10, null));

            // Satış yoksa gösterilen yazı
            lblBos = new Label();
            lblBos.Text = "Henüz satış yapmadınız.";
            lblBos.Bounds = new Rectangle(1, 60, kart.Width - 2, 50);
            lblBos.TextAlign = ContentAlignment.MiddleCenter;
            lblBos.Font = new Font("Segoe UI", 9.5F);
            lblBos.ForeColor = Gri;
            lblBos.BackColor = Color.White;
            lblBos.Visible = false;
            kart.Controls.Add(lblBos);
            lblBos.BringToFront();
        }

        static DataGridViewTextBoxColumn Kolon(string ad, string baslik, string alan, float agirlik, string bicim)
        {
            var c = new DataGridViewTextBoxColumn();
            c.Name = ad;
            c.HeaderText = baslik;
            c.DataPropertyName = alan;
            c.FillWeight = agirlik;
            if (bicim != null) c.DefaultCellStyle.Format = bicim;
            return c;
        }

        static Label Etiket(string metin, int x, int y, Font font, Color renk)
        {
            var l = new Label();
            l.Text = metin;
            l.Location = new Point(x, y);
            l.AutoSize = true;
            l.Font = font;
            l.ForeColor = renk;
            l.BackColor = Color.Transparent;
            return l;
        }

        static Panel Kart(int x, int y, int w, int h)
        {
            var p = new Panel();
            p.Location = new Point(x, y);
            p.Size = new Size(w, h);
            p.BackColor = Color.White;
            p.Paint += (s, e) =>
            {
                using (var kalem = new Pen(Cizgi))
                    e.Graphics.DrawRectangle(kalem, 0, 0, p.Width - 1, p.Height - 1);
            };
            return p;
        }

        static void GridStili(DataGridView g)
        {
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.RowHeadersVisible = false;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.AllowUserToResizeColumns = false;
            g.ReadOnly = true;
            g.MultiSelect = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.AutoGenerateColumns = false;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Cizgi;
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            g.ColumnHeadersHeight = 40;
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Gri;
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.SelectionForeColor = Gri;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
            g.RowTemplate.Height = 40;
            g.DefaultCellStyle.Font = new Font("Segoe UI", 9.5F);
            g.DefaultCellStyle.ForeColor = Lacivert;
            g.DefaultCellStyle.BackColor = Color.White;
            g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(253, 244, 228);
            g.DefaultCellStyle.SelectionForeColor = Lacivert;
        }

        // ---------------------------------------------------------------
        //  Veri
        // ---------------------------------------------------------------
        void SatislariYukle()
        {
            yuklendi = true;
            try
            {
                DataTable dt = Veritabani.Tablo(
                    "SELECT Kod, Ad, Guzergah, " +
                    "CONVERT(NVARCHAR(10), Tarih, 104) + N' ' + Saat AS TarihSaat, " +
                    "Koltuklar, Tutar, KomisyonTutari, " +
                    "UPPER(LEFT(Durum, 1)) + SUBSTRING(Durum, 2, LEN(Durum)) AS Durum " +
                    "FROM Rezervasyonlar WHERE AcenteId=@a ORDER BY Id DESC",
                    new SqlParameter("@a", Oturum.AcenteId));

                grid.DataSource = dt;
                lblBos.Visible = dt.Rows.Count == 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Satışlar yüklenemedi:\n" + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}