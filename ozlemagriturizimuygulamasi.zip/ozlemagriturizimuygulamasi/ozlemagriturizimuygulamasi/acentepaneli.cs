﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace ozlemagriturizimuygulamasi
{
    public partial class acentepaneli : Form
    {
        // Tasarımdaki renkler
        static readonly Color Zemin = Color.FromArgb(245, 247, 250);
        static readonly Color Lacivert = Color.FromArgb(10, 21, 36);
        static readonly Color Gri = Color.FromArgb(100, 116, 139);
        static readonly Color Cizgi = Color.FromArgb(226, 232, 240);
        static readonly Color Altin = Color.FromArgb(194, 145, 63);

        Label lblBilet;
        Label lblTutar;
        Label lblKomisyon;
        Label lblBekleyen;
        Panel kartSon;
        DataGridView grid;
        Label lblBosSon;
        bool yuklendi;

        public acentepaneli()
        {
            InitializeComponent();

            Text = "Özlem Ağrı Turizm - Genel Bakış";
            ClientSize = new Size(1133, 614);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Sayfa.MenuKur(this,
                new Rectangle(12, 139, 167, 36),   // Genel Bakış
                new Rectangle(12, 177, 167, 36),   // Bilet Sat
                new Rectangle(12, 215, 167, 36),   // Satışlarım
                new Rectangle(12, 562, 167, 31));  // Çıkış Yap

            ArayuzKur();

            // Designer'daki Load bağlantısı bir sebeple yoksa yine de yüklensin
            Shown += (s, e) => { if (!yuklendi) Yukle(); };
        }

        // Designer'daki Load olayına bağlı mevcut metot
        private void acentepaneli_Load(object sender, EventArgs e)
        {
            Yukle();
        }

        // ---------------------------------------------------------------
        //  Arayüz (sol menü resimde kalıyor, sağ taraf gerçek kontroller)
        // ---------------------------------------------------------------
        void ArayuzKur()
        {
            var icerik = new Panel();
            icerik.BackColor = Zemin;
            icerik.Location = new Point(191, 0);
            icerik.Size = new Size(ClientSize.Width - 191, ClientSize.Height);
            Controls.Add(icerik);

            icerik.Controls.Add(Etiket("Genel Bakış", 26, 20, new Font("Segoe UI", 18F, FontStyle.Bold), Lacivert));
            icerik.Controls.Add(Etiket("Acente satış özetiniz", 28, 60, new Font("Segoe UI", 9.5F), Gri));

            lblBilet = OzetKarti(icerik, 26, "#", "Toplam Sattığınız Bilet");
            lblTutar = OzetKarti(icerik, 252, "₺", "Toplam Satış Tutarı");
            lblKomisyon = OzetKarti(icerik, 478, "%", "Tahmini Komisyonunuz");
            lblBekleyen = OzetKarti(icerik, 704, "◷", "Bekleyen Rezervasyon");

            // --- Son satışlar kartı ---
            kartSon = Kart(26, 190, 890, 88);
            icerik.Controls.Add(kartSon);
            kartSon.Controls.Add(Etiket("Son Satışlarınız", 16, 16, new Font("Segoe UI", 11F, FontStyle.Bold), Lacivert));

            lblBosSon = Etiket("Henüz satış yapmadınız.", 16, 48, new Font("Segoe UI", 9.5F), Gri);
            kartSon.Controls.Add(lblBosSon);

            grid = new DataGridView();
            GridStili(grid);
            grid.RowTemplate.Height = 36;
            grid.ScrollBars = ScrollBars.None;
            grid.Location = new Point(1, 46);
            grid.Width = kartSon.Width - 2;
            grid.Visible = false;
            kartSon.Controls.Add(grid);

            grid.Columns.Add(Kolon("colKod", "KOD", "Kod", 14, null));
            grid.Columns.Add(Kolon("colYolcu", "YOLCU", "Ad", 24, null));
            grid.Columns.Add(Kolon("colGuzergah", "GÜZERGAH", "Guzergah", 26, null));
            grid.Columns.Add(Kolon("colTarih", "TARİH", "TarihSaat", 20, null));
            grid.Columns.Add(Kolon("colTutar", "TUTAR (TL)", "Tutar", 16, "N2"));
        }

        // Üstteki 4 özet kartından birini kurar, değer yazısını (Label) döndürür
        static Label OzetKarti(Control ebeveyn, int x, string simge, string baslik)
        {
            Panel k = Kart(x, 92, 212, 74);
            ebeveyn.Controls.Add(k);

            var ikon = new Label();
            ikon.Text = simge;
            ikon.Font = new Font("Segoe UI Symbol", 14F, FontStyle.Bold);
            ikon.ForeColor = Altin;
            ikon.BackColor = Color.FromArgb(253, 240, 218);
            ikon.TextAlign = ContentAlignment.MiddleCenter;
            ikon.Bounds = new Rectangle(16, 18, 38, 38);
            k.Controls.Add(ikon);

            Label deger = Etiket("0", 66, 12, new Font("Segoe UI", 15F, FontStyle.Bold), Lacivert);
            k.Controls.Add(deger);
            k.Controls.Add(Etiket(baslik, 67, 46, new Font("Segoe UI", 8F), Gri));
            return deger;
        }

        static DataGridViewTextBoxColumn Kolon(string ad, string baslik, string alan, float agirlik, string bicim)
        {
            var c = new DataGridViewTextBoxColumn();
            c.Name = ad;
            c.HeaderText = baslik;
            c.DataPropertyName = alan;
            c.FillWeight = agirlik;
            if (bicim != null) c.DefaultCellStyle.Format = bicim;
            return c;
        }

        static Label Etiket(string metin, int x, int y, Font font, Color renk)
        {
            var l = new Label();
            l.Text = metin;
            l.Location = new Point(x, y);
            l.AutoSize = true;
            l.Font = font;
            l.ForeColor = renk;
            l.BackColor = Color.Transparent;
            return l;
        }

        static Panel Kart(int x, int y, int w, int h)
        {
            var p = new Panel();
            p.Location = new Point(x, y);
            p.Size = new Size(w, h);
            p.BackColor = Color.White;
            p.Paint += (s, e) =>
            {
                using (var kalem = new Pen(Cizgi))
                    e.Graphics.DrawRectangle(kalem, 0, 0, p.Width - 1, p.Height - 1);
            };
            return p;
        }

        static void GridStili(DataGridView g)
        {
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.RowHeadersVisible = false;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.AllowUserToResizeColumns = false;
            g.ReadOnly = true;
            g.MultiSelect = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.AutoGenerateColumns = false;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Cizgi;
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            g.ColumnHeadersHeight = 40;
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Gri;
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.SelectionForeColor = Gri;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
            g.DefaultCellStyle.Font = new Font("Segoe UI", 9.5F);
            g.DefaultCellStyle.ForeColor = Lacivert;
            g.DefaultCellStyle.BackColor = Color.White;
            g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(253, 244, 228);
            g.DefaultCellStyle.SelectionForeColor = Lacivert;
        }

        // ---------------------------------------------------------------
        //  Veri
        // ---------------------------------------------------------------
        void Yukle()
        {
            yuklendi = true;
            try
            {
                DataTable ozet = Veritabani.Tablo(
                    "SELECT ISNULL(SUM(KoltukSayisi), 0) AS Bilet, " +
                    "ISNULL(SUM(Tutar), 0) AS Tutar, " +
                    "ISNULL(SUM(KomisyonTutari), 0) AS Komisyon, " +
                    "COUNT(CASE WHEN Durum = N'beklemede' THEN 1 END) AS Bekleyen " +
                    "FROM Rezervasyonlar WHERE AcenteId=@a",
                    new SqlParameter("@a", Oturum.AcenteId));

                DataRow r = ozet.Rows[0];
                lblBilet.Text = Convert.ToInt32(r["Bilet"]).ToString("N0");
                lblTutar.Text = Convert.ToDecimal(r["Tutar"]).ToString("#,##0.##") + " TL";
                lblKomisyon.Text = Convert.ToDecimal(r["Komisyon"]).ToString("#,##0.##") + " TL";
                lblBekleyen.Text = Convert.ToInt32(r["Bekleyen"]).ToString("N0");

                DataTable son = Veritabani.Tablo(
                    "SELECT TOP 5 Kod, Ad, Guzergah, " +
                    "CONVERT(NVARCHAR(10), Tarih, 104) + N' ' + Saat AS TarihSaat, Tutar " +
                    "FROM Rezervasyonlar WHERE AcenteId=@a ORDER BY Id DESC",
                    new SqlParameter("@a", Oturum.AcenteId));

                if (son.Rows.Count == 0)
                {
                    grid.Visible = false;
                    lblBosSon.Visible = true;
                    kartSon.Height = 88;
                }
                else
                {
                    grid.DataSource = son;
                    grid.Height = 40 + son.Rows.Count * 36 + 2;
                    grid.Visible = true;
                    lblBosSon.Visible = false;
                    kartSon.Height = 46 + grid.Height + 8;
                }
                kartSon.Invalidate();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Genel bakış verileri yüklenemedi:\n" + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}