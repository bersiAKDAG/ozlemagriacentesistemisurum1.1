﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ozlemagriturizimuygulamasi
{
    public partial class sistemegiris : Form
    {
        public sistemegiris()
        {
            InitializeComponent();
            Load += sistemegiris_Load;
        }

        private void sistemegiris_Load(object sender, EventArgs e)
        {
            txtkullaniciadi.BorderStyle = BorderStyle.FixedSingle;
            txtsifregiris.BorderStyle = BorderStyle.FixedSingle;
            txtsifregiris.UseSystemPasswordChar = false;
            txtsifregiris.PasswordChar = '●';
            AcceptButton = button1;
        }

        public void GirisEkraninaDon()
        {
            Show();
            txtkullaniciadi.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string kullanici = txtkullaniciadi.Text.Trim();
            string sifre = txtsifregiris.Text;

            if (kullanici == "" || sifre == "")
            {
                MessageBox.Show("Kullanıcı adı ve şifre girin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataTable dt;
            try
            {
                dt = Veritabani.Tablo(
                    "SELECT Id, AcenteAdi, Sehir, KomisyonOrani FROM Acenteler WHERE KullaniciAdi=@u AND Sifre=@p AND Aktif=1",
                    new SqlParameter("@u", kullanici),
                    new SqlParameter("@p", sifre));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanına bağlanılamadı:\n" + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Kullanıcı adı veya şifre hatalı, ya da hesabınız pasif durumda.", "Giriş Başarısız", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtsifregiris.Clear();
                txtsifregiris.Focus();
                return;
            }

            DataRow r = dt.Rows[0];
            Oturum.AcenteId = Convert.ToInt32(r["Id"]);
            Oturum.AcenteAdi = r["AcenteAdi"].ToString();
            Oturum.Sehir = r["Sehir"].ToString();
            Oturum.KomisyonOrani = Convert.ToDecimal(r["KomisyonOrani"]);

            txtkullaniciadi.Clear();
            txtsifregiris.Clear();

            Hide();
            new acentepaneli().Show();
        }
    }
}