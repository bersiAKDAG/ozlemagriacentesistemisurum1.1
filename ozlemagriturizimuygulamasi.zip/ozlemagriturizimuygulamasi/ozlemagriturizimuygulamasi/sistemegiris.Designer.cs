﻿
namespace ozlemagriturizimuygulamasi
{
    partial class sistemegiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtkullaniciadi = new System.Windows.Forms.TextBox();
            this.txtsifregiris = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(220, 341);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(360, 37);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtkullaniciadi
            // 
            this.txtkullaniciadi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtkullaniciadi.Location = new System.Drawing.Point(231, 244);
            this.txtkullaniciadi.Multiline = true;
            this.txtkullaniciadi.Name = "txtkullaniciadi";
            this.txtkullaniciadi.Size = new System.Drawing.Size(338, 23);
            this.txtkullaniciadi.TabIndex = 3;
            // 
            // txtsifregiris
            // 
            this.txtsifregiris.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtsifregiris.Location = new System.Drawing.Point(230, 302);
            this.txtsifregiris.Multiline = true;
            this.txtsifregiris.Name = "txtsifregiris";
            this.txtsifregiris.Size = new System.Drawing.Size(338, 23);
            this.txtsifregiris.TabIndex = 4;
        
            // 
            // sistemegiris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ozlemagriturizimuygulamasi.Properties.Resources.Özlem_Ağrı_Acente_Giriş_Paneli__1_;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.txtsifregiris);
            this.Controls.Add(this.txtkullaniciadi);
            this.Controls.Add(this.button1);
            this.Name = "sistemegiris";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtkullaniciadi;
        private System.Windows.Forms.TextBox txtsifregiris;
    }
}

