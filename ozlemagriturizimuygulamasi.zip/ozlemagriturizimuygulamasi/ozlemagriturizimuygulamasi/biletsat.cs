﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace ozlemagriturizimuygulamasi
{
    public partial class biletsat : Form
    {
        // Tasarımdaki renkler
        static readonly Color Zemin = Color.FromArgb(245, 247, 250);
        static readonly Color Lacivert = Color.FromArgb(10, 21, 36);
        static readonly Color Gri = Color.FromArgb(100, 116, 139);
        static readonly Color Cizgi = Color.FromArgb(226, 232, 240);
        static readonly Color Altin = Color.FromArgb(194, 145, 63);

        ComboBox cmbKalkis;
        ComboBox cmbVaris;
        DateTimePicker dtpTarih;
        Button btnAra;
        Label lblDurum;
        DataGridView grid;
        DataGridViewButtonColumn colSat;

        class Yolcu
        {
            public string Ad;
            public string Tc;
            public string Tel;
            public int Adet;
        }

        public biletsat()
        {
            InitializeComponent();

            Text = "Özlem Ağrı Turizm - Bilet Sat";
            ClientSize = new Size(1133, 614);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            Sayfa.MenuKur(this,
                new Rectangle(12, 137, 167, 36),   // Genel Bakış
                new Rectangle(12, 175, 167, 35),   // Bilet Sat
                new Rectangle(12, 213, 167, 36),   // Satışlarım
                new Rectangle(12, 562, 167, 31));  // Çıkış Yap

            ArayuzKur();
            Load += (s, e) => SehirleriYukle();
        }

        // ---------------------------------------------------------------
        //  Arayüz (sol menü resimde kalıyor, sağ taraf gerçek kontroller)
        // ---------------------------------------------------------------
        void ArayuzKur()
        {
            var icerik = new Panel();
            icerik.BackColor = Zemin;
            icerik.Location = new Point(191, 0);
            icerik.Size = new Size(ClientSize.Width - 191, ClientSize.Height);
            Controls.Add(icerik);

            icerik.Controls.Add(Etiket("Bilet Sat", 26, 20, new Font("Segoe UI", 18F, FontStyle.Bold), Lacivert));
            icerik.Controls.Add(Etiket("Sefer arayın ve yolcu adına bilet satın", 28, 60, new Font("Segoe UI", 9.5F), Gri));

            // --- Arama kartı ---
            Panel arama = Kart(26, 92, 890, 92);
            icerik.Controls.Add(arama);

            Font kucukKalin = new Font("Segoe UI", 8F, FontStyle.Bold);
            arama.Controls.Add(Etiket("KALKIŞ", 16, 14, kucukKalin, Lacivert));
            arama.Controls.Add(Etiket("VARIŞ", 231, 14, kucukKalin, Lacivert));
            arama.Controls.Add(Etiket("TARİH", 446, 14, kucukKalin, Lacivert));

            cmbKalkis = Combo(16, 38, 205);
            cmbVaris = Combo(231, 38, 205);
            arama.Controls.Add(cmbKalkis);
            arama.Controls.Add(cmbVaris);

            dtpTarih = new DateTimePicker();
            dtpTarih.Location = new Point(446, 38);
            dtpTarih.Width = 205;
            dtpTarih.Font = new Font("Segoe UI", 10.5F);
            dtpTarih.Format = DateTimePickerFormat.Short;
            dtpTarih.MinDate = DateTime.Today;
            dtpTarih.Value = DateTime.Today;
            arama.Controls.Add(dtpTarih);

            btnAra = new Button();
            btnAra.Text = "Sefer Ara";
            btnAra.Location = new Point(661, 36);
            btnAra.Size = new Size(205, 32);
            btnAra.FlatStyle = FlatStyle.Flat;
            btnAra.FlatAppearance.BorderSize = 0;
            btnAra.BackColor = Altin;
            btnAra.ForeColor = Lacivert;
            btnAra.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnAra.Cursor = Cursors.Hand;
            btnAra.Click += (s, e) => SeferAra();
            arama.Controls.Add(btnAra);

            // --- Durum yazısı ---
            lblDurum = Etiket("Şehir ve tarih seçip \"Sefer Ara\" düğmesine basın.", 28, 196, new Font("Segoe UI", 9.5F), Gri);
            icerik.Controls.Add(lblDurum);

            // --- Sonuç kartı ---
            Panel sonuc = Kart(26, 222, 890, ClientSize.Height - 222 - 24);
            sonuc.Padding = new Padding(1);
            icerik.Controls.Add(sonuc);

            grid = new DataGridView();
            GridStili(grid);
            grid.Dock = DockStyle.Fill;
            sonuc.Controls.Add(grid);

            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colId", DataPropertyName = "Id", Visible = false });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colSaat", HeaderText = "SAAT", DataPropertyName = "Saat", FillWeight = 10 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colGuzergah", HeaderText = "GÜZERGAH", DataPropertyName = "Guzergah", FillWeight = 28 });
            var colFiyat = new DataGridViewTextBoxColumn { Name = "colFiyat", HeaderText = "FİYAT (TL)", DataPropertyName = "Fiyat", FillWeight = 14 };
            colFiyat.DefaultCellStyle.Format = "N2";
            grid.Columns.Add(colFiyat);
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colBos", HeaderText = "BOŞ KOLTUK", DataPropertyName = "Bos", FillWeight = 14 });
            grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colPlaka", HeaderText = "PLAKA", DataPropertyName = "Plaka", FillWeight = 16 });

            colSat = new DataGridViewButtonColumn();
            colSat.Name = "colSat";
            colSat.HeaderText = "";
            colSat.Text = "Bilet Sat";
            colSat.UseColumnTextForButtonValue = true;
            colSat.FlatStyle = FlatStyle.Flat;
            colSat.FillWeight = 16;
            colSat.DefaultCellStyle.BackColor = Altin;
            colSat.DefaultCellStyle.ForeColor = Lacivert;
            colSat.DefaultCellStyle.SelectionBackColor = Altin;
            colSat.DefaultCellStyle.SelectionForeColor = Lacivert;
            colSat.DefaultCellStyle.Padding = new Padding(8, 6, 8, 6);
            grid.Columns.Add(colSat);

            grid.CellContentClick += GridTikla;
        }

        static Label Etiket(string metin, int x, int y, Font font, Color renk)
        {
            var l = new Label();
            l.Text = metin;
            l.Location = new Point(x, y);
            l.AutoSize = true;
            l.Font = font;
            l.ForeColor = renk;
            l.BackColor = Color.Transparent;
            return l;
        }

        static Panel Kart(int x, int y, int w, int h)
        {
            var p = new Panel();
            p.Location = new Point(x, y);
            p.Size = new Size(w, h);
            p.BackColor = Color.White;
            p.Paint += (s, e) =>
            {
                using (var kalem = new Pen(Cizgi))
                    e.Graphics.DrawRectangle(kalem, 0, 0, p.Width - 1, p.Height - 1);
            };
            return p;
        }

        static ComboBox Combo(int x, int y, int w)
        {
            var c = new ComboBox();
            c.Location = new Point(x, y);
            c.Width = w;
            c.DropDownStyle = ComboBoxStyle.DropDownList;
            c.Font = new Font("Segoe UI", 10.5F);
            return c;
        }

        static void GridStili(DataGridView g)
        {
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.RowHeadersVisible = false;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.AllowUserToResizeColumns = false;
            g.ReadOnly = true;
            g.MultiSelect = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.AutoGenerateColumns = false;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Cizgi;
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            g.ColumnHeadersHeight = 40;
            g.ColumnHeadersDefaultCellStyle.BackColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Gri;
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.SelectionForeColor = Gri;
            g.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 8F, FontStyle.Bold);
            g.RowTemplate.Height = 40;
            g.DefaultCellStyle.Font = new Font("Segoe UI", 9.5F);
            g.DefaultCellStyle.ForeColor = Lacivert;
            g.DefaultCellStyle.BackColor = Color.White;
            g.DefaultCellStyle.SelectionBackColor = Color.FromArgb(253, 244, 228);
            g.DefaultCellStyle.SelectionForeColor = Lacivert;
        }

        // ---------------------------------------------------------------
        //  Veri
        // ---------------------------------------------------------------
        void SehirleriYukle()
        {
            try
            {
                DataTable dt = Veritabani.Tablo("SELECT Ad FROM Sehirler ORDER BY Ad");
                foreach (DataRow r in dt.Rows)
                {
                    string ad = r["Ad"].ToString();
                    cmbKalkis.Items.Add(ad);
                    cmbVaris.Items.Add(ad);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Şehirler yüklenemedi:\n" + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (cmbKalkis.Items.Count == 0) return;

            int k = cmbKalkis.Items.IndexOf(Oturum.Sehir);
            cmbKalkis.SelectedIndex = k >= 0 ? k : 0;

            int v = cmbVaris.Items.IndexOf("İstanbul");
            if (v < 0 || v == cmbKalkis.SelectedIndex)
                v = cmbVaris.Items.Count > 1 ? (cmbKalkis.SelectedIndex == 0 ? 1 : 0) : 0;
            cmbVaris.SelectedIndex = v;
        }

        void SeferAra()
        {
            if (cmbKalkis.SelectedItem == null || cmbVaris.SelectedItem == null)
            {
                MessageBox.Show("Kalkış ve varış şehrini seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string kalkis = cmbKalkis.SelectedItem.ToString();
            string varis = cmbVaris.SelectedItem.ToString();
            if (kalkis == varis)
            {
                MessageBox.Show("Kalkış ve varış şehri aynı olamaz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DataTable dt = Veritabani.Tablo(
                    "SELECT Id, Saat, Kalkis + N' → ' + Varis AS Guzergah, Fiyat, " +
                    "Koltuk - DoluKoltuk AS Bos, ISNULL(Plaka, N'-') AS Plaka " +
                    "FROM Seferler WHERE Kalkis=@k AND Varis=@v AND Tarih=@t ORDER BY Saat",
                    new SqlParameter("@k", kalkis),
                    new SqlParameter("@v", varis),
                    new SqlParameter("@t", dtpTarih.Value.Date));

                grid.DataSource = dt;
                lblDurum.Text = dt.Rows.Count == 0
                    ? "Bu tarih ve güzergah için sefer bulunamadı."
                    : dt.Rows.Count + " sefer bulundu.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seferler yüklenemedi:\n" + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void GridTikla(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != colSat.Index) return;

            DataGridViewRow satir = grid.Rows[e.RowIndex];
            int seferId = Convert.ToInt32(satir.Cells["colId"].Value);
            decimal fiyat = Convert.ToDecimal(satir.Cells["colFiyat"].Value);
            int bos = Convert.ToInt32(satir.Cells["colBos"].Value);
            string baslik = satir.Cells["colGuzergah"].Value + "  -  " + satir.Cells["colSaat"].Value;

            if (bos <= 0)
            {
                MessageBox.Show("Bu seferde boş koltuk kalmadı.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Yolcu y = YolcuSor(baslik, fiyat, bos);
            if (y == null) return;

            try
            {
                string sonuc = Veritabani.BiletSat(seferId, Oturum.AcenteId, Oturum.KomisyonOrani, y.Ad, y.Tc, y.Tel, y.Adet);
                string[] parca = sonuc.Split('|');
                MessageBox.Show(
                    "Bilet satışı tamamlandı.\n\nRezervasyon kodu: " + parca[0] + "\nKoltuk no: " + parca[1],
                    "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Satış yapılamadı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            SeferAra();   // boş koltuk sayısını yenile
        }

        // ---------------------------------------------------------------
        //  Yolcu bilgisi penceresi (koddan oluşturuluyor)
        // ---------------------------------------------------------------
        Yolcu YolcuSor(string baslik, decimal fiyat, int bos)
        {
            Yolcu sonuc = null;

            using (var f = new Form())
            {
                f.Text = "Yolcu Bilgileri";
                f.FormBorderStyle = FormBorderStyle.FixedDialog;
                f.StartPosition = FormStartPosition.CenterParent;
                f.MaximizeBox = false;
                f.MinimizeBox = false;
                f.ShowInTaskbar = false;
                f.ClientSize = new Size(380, 410);
                f.BackColor = Color.White;
                f.Font = new Font("Segoe UI", 10F);

                f.Controls.Add(Etiket(baslik, 20, 16, new Font("Segoe UI", 10.5F, FontStyle.Bold), Lacivert));

                TextBox txtAd = Kutu(f, "AD SOYAD", 20, 56, 100);
                TextBox txtTc = Kutu(f, "TC KİMLİK NO", 20, 116, 11);
                TextBox txtTel = Kutu(f, "TELEFON", 20, 176, 20);

                f.Controls.Add(Etiket("BİLET ADEDİ", 20, 236, new Font("Segoe UI", 8F, FontStyle.Bold), Lacivert));
                var nud = new NumericUpDown();
                nud.Location = new Point(20, 256);
                nud.Width = 100;
                nud.Minimum = 1;
                nud.Maximum = bos;
                nud.Value = 1;
                f.Controls.Add(nud);

                var lblToplam = Etiket("", 20, 300, new Font("Segoe UI", 9.5F, FontStyle.Bold), Lacivert);
                f.Controls.Add(lblToplam);

                Action guncelle = () =>
                {
                    decimal tutar = fiyat * nud.Value;
                    decimal komisyon = Math.Round(tutar * Oturum.KomisyonOrani / 100);
                    lblToplam.Text = "Tutar: " + tutar.ToString("N2") + " TL     Komisyonunuz: " + komisyon.ToString("N2") + " TL";
                };
                nud.ValueChanged += (s, e) => guncelle();
                guncelle();

                var btnTamam = new Button();
                btnTamam.Text = "Satışı Tamamla";
                btnTamam.Location = new Point(20, 350);
                btnTamam.Size = new Size(210, 40);
                btnTamam.FlatStyle = FlatStyle.Flat;
                btnTamam.FlatAppearance.BorderSize = 0;
                btnTamam.BackColor = Altin;
                btnTamam.ForeColor = Lacivert;
                btnTamam.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
                f.Controls.Add(btnTamam);

                var btnIptal = new Button();
                btnIptal.Text = "İptal";
                btnIptal.Location = new Point(240, 350);
                btnIptal.Size = new Size(120, 40);
                btnIptal.DialogResult = DialogResult.Cancel;
                f.Controls.Add(btnIptal);

                f.AcceptButton = btnTamam;
                f.CancelButton = btnIptal;

                btnTamam.Click += (s, e) =>
                {
                    string ad = txtAd.Text.Trim();
                    string tc = txtTc.Text.Trim();
                    string tel = txtTel.Text.Trim();

                    if (ad.Length < 3)
                    {
                        MessageBox.Show("Yolcunun adını ve soyadını girin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtAd.Focus();
                        return;
                    }
                    if (!TcGecerliMi(tc))
                    {
                        MessageBox.Show("TC kimlik numarası 11 haneli ve sadece rakamlardan oluşmalı.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtTc.Focus();
                        return;
                    }
                    if (RakamSayisi(tel) < 10)
                    {
                        MessageBox.Show("Geçerli bir telefon numarası girin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtTel.Focus();
                        return;
                    }

                    sonuc = new Yolcu { Ad = ad, Tc = tc, Tel = tel, Adet = (int)nud.Value };
                    f.DialogResult = DialogResult.OK;
                };

                f.ShowDialog(this);
            }

            return sonuc;
        }

        static TextBox Kutu(Form f, string etiket, int x, int y, int enFazla)
        {
            f.Controls.Add(Etiket(etiket, x, y, new Font("Segoe UI", 8F, FontStyle.Bold), Lacivert));
            var t = new TextBox();
            t.Location = new Point(x, y + 20);
            t.Width = 340;
            t.MaxLength = enFazla;
            f.Controls.Add(t);
            return t;
        }

        static bool TcGecerliMi(string tc)
        {
            if (tc.Length != 11) return false;
            foreach (char c in tc)
                if (c < '0' || c > '9') return false;
            return true;
        }

        static int RakamSayisi(string metin)
        {
            int n = 0;
            foreach (char c in metin)
                if (c >= '0' && c <= '9') n++;
            return n;
        }
    }
}