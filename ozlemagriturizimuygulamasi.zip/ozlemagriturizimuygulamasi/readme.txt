VERİTABANI KODLARI

CREATE DATABASE OzlemAgriAcente; // TEK SEFERLİK VERİTABANI OLUŞTURMAK İÇİN ÇALIŞTIRILIR.


USE OzlemAgriAcente;
GO

CREATE TABLE Sehirler (
    Id INT IDENTITY PRIMARY KEY,
    Ad NVARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE Acenteler (
    Id INT IDENTITY PRIMARY KEY,
    AcenteAdi NVARCHAR(100) NOT NULL,
    Sehir NVARCHAR(60) NOT NULL,
    KullaniciAdi NVARCHAR(50) NOT NULL UNIQUE,
    Sifre NVARCHAR(100) NOT NULL,
    KomisyonOrani DECIMAL(5,2) NOT NULL DEFAULT 0,
    Aktif BIT NOT NULL DEFAULT 1
);

CREATE TABLE Seferler (
    Id INT IDENTITY PRIMARY KEY,
    Kalkis NVARCHAR(60) NOT NULL,
    Varis NVARCHAR(60) NOT NULL,
    Tarih DATE NOT NULL,
    Saat NVARCHAR(5) NOT NULL,
    Fiyat DECIMAL(10,2) NOT NULL,
    Koltuk INT NOT NULL,
    DoluKoltuk INT NOT NULL DEFAULT 0,
    Plaka NVARCHAR(20) NULL
);

CREATE TABLE Rezervasyonlar (
    Id INT IDENTITY PRIMARY KEY,
    SeferId INT NOT NULL REFERENCES Seferler(Id),
    Kod NVARCHAR(20) NOT NULL UNIQUE,
    Ad NVARCHAR(100) NOT NULL,
    Tc CHAR(11) NOT NULL,
    Telefon NVARCHAR(20) NOT NULL,
    KoltukSayisi INT NOT NULL,
    Koltuklar NVARCHAR(100) NOT NULL,
    Guzergah NVARCHAR(150) NOT NULL,
    Tarih DATE NOT NULL,
    Saat NVARCHAR(5) NOT NULL,
    Tutar DECIMAL(10,2) NOT NULL,
    Durum NVARCHAR(20) NOT NULL DEFAULT 'beklemede',
    SatisKanali NVARCHAR(20) NOT NULL DEFAULT 'acente',
    AcenteId INT NULL REFERENCES Acenteler(Id),
    KomisyonTutari DECIMAL(10,2) NOT NULL DEFAULT 0,
    TarihOlusturma DATETIME NOT NULL DEFAULT GETDATE()
);

INSERT INTO Sehirler (Ad) VALUES (N'Ağrı'),(N'İstanbul'),(N'Ankara'),(N'Erzurum'),(N'Van');
INSERT INTO Acenteler (AcenteAdi, Sehir, KullaniciAdi, Sifre, KomisyonOrani)
VALUES (N'Ağrı Acente', N'Ağrı', 'agri', 'Agri#Admin2026!', 10);
INSERT INTO Seferler (Kalkis, Varis, Tarih, Saat, Fiyat, Koltuk, Plaka)
VALUES (N'Ağrı', N'İstanbul', CAST(GETDATE() AS DATE), '20:00', 1500, 40, '04 AGR 001');