﻿using System;
using System.Data;
using System.Data.SqlClient;

public static class Veritabani
{
    public const string BaglantiMetni = "Server=localhost\\SQLEXPRESS;Database=OzlemAgriAcente;Trusted_Connection=True;";

    public static DataTable Tablo(string sql, params SqlParameter[] p)
    {
        using (var c = new SqlConnection(BaglantiMetni))
        using (var cmd = new SqlCommand(sql, c))
        using (var da = new SqlDataAdapter(cmd))
        {
            cmd.Parameters.AddRange(p);
            var dt = new DataTable();
            da.Fill(dt);
            return dt;
        }
    }

    public static object Tek(string sql, params SqlParameter[] p)
    {
        using (var c = new SqlConnection(BaglantiMetni))
        using (var cmd = new SqlCommand(sql, c))
        {
            cmd.Parameters.AddRange(p);
            c.Open();
            return cmd.ExecuteScalar();
        }
    }

    public static string BiletSat(int seferId, int acenteId, decimal komisyonOrani, string ad, string tc, string tel, int adet)
    {
        using (var c = new SqlConnection(BaglantiMetni))
        {
            c.Open();
            using (var tr = c.BeginTransaction())
            {
                try
                {
                    var cmd = new SqlCommand("SELECT Kalkis,Varis,Tarih,Saat,Fiyat,Koltuk,DoluKoltuk FROM Seferler WITH (UPDLOCK) WHERE Id=@id", c, tr);
                    cmd.Parameters.AddWithValue("@id", seferId);
                    string kalkis, varis, saat; DateTime tarih; decimal fiyat; int koltuk, dolu;
                    using (var r = cmd.ExecuteReader())
                    {
                        if (!r.Read()) throw new Exception("Sefer bulunamadı.");
                        kalkis = r.GetString(0); varis = r.GetString(1); tarih = r.GetDateTime(2);
                        saat = r.GetString(3); fiyat = r.GetDecimal(4); koltuk = r.GetInt32(5); dolu = r.GetInt32(6);
                    }
                    if (adet > koltuk - dolu) throw new Exception("Bu seferde sadece " + (koltuk - dolu) + " boş koltuk var.");

                    var koltuklar = new string[adet];
                    for (int i = 0; i < adet; i++) koltuklar[i] = (dolu + i + 1).ToString();
                    string kod = "OA-" + Guid.NewGuid().ToString("N").Substring(0, 6).ToUpper();
                    decimal tutar = fiyat * adet;
                    decimal komisyon = Math.Round(tutar * komisyonOrani / 100);

                    var ins = new SqlCommand(@"INSERT INTO Rezervasyonlar
                        (SeferId,Kod,Ad,Tc,Telefon,KoltukSayisi,Koltuklar,Guzergah,Tarih,Saat,Tutar,SatisKanali,AcenteId,KomisyonTutari)
                        VALUES (@s,@k,@a,@tc,@t,@n,@ko,@g,@d,@sa,@tu,'acente',@ac,@km)", c, tr);
                    ins.Parameters.AddWithValue("@s", seferId);
                    ins.Parameters.AddWithValue("@k", kod);
                    ins.Parameters.AddWithValue("@a", ad);
                    ins.Parameters.AddWithValue("@tc", tc);
                    ins.Parameters.AddWithValue("@t", tel);
                    ins.Parameters.AddWithValue("@n", adet);
                    ins.Parameters.AddWithValue("@ko", string.Join(", ", koltuklar));
                    ins.Parameters.AddWithValue("@g", kalkis + " → " + varis);
                    ins.Parameters.AddWithValue("@d", tarih);
                    ins.Parameters.AddWithValue("@sa", saat);
                    ins.Parameters.AddWithValue("@tu", tutar);
                    ins.Parameters.AddWithValue("@ac", acenteId);
                    ins.Parameters.AddWithValue("@km", komisyon);
                    ins.ExecuteNonQuery();

                    var upd = new SqlCommand("UPDATE Seferler SET DoluKoltuk=DoluKoltuk+@n WHERE Id=@id", c, tr);
                    upd.Parameters.AddWithValue("@n", adet);
                    upd.Parameters.AddWithValue("@id", seferId);
                    upd.ExecuteNonQuery();

                    tr.Commit();
                    return kod + "|" + string.Join(", ", koltuklar);
                }
                catch
                {
                    tr.Rollback();
                    throw;
                }
            }
        }
    }
}

public static class Oturum
{
    public static int AcenteId;
    public static string AcenteAdi;
    public static string Sehir;
    public static decimal KomisyonOrani;
}